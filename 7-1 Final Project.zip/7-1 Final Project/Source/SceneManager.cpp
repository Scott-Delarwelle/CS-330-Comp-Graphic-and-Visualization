///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for setting up the lighting in the 3D scene,
 *  including positions, ambient, diffuse, and specular colors.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable custom lighting in the shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Top-Left Front Light (Angled)
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-12.0f, 20.0f, 12.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.15f, 0.08f, 0.04f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.95f, 0.50f, 0.15f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.85f, 0.55f, 0.25f));
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);

	// Top-Right Front Light (Angled)
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(12.0f, 20.0f, 12.0f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.08f, 0.05f, 0.12f));
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.55f, 0.35f, 0.65f));
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.45f, 0.30f, 0.55f));
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);

	// Low Left Side Light
	m_pShaderManager->setVec3Value("lightSources[2].position", glm::vec3(-12.0f, 6.0f, -6.0f));
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.1f, 0.05f, 0.02f));
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(0.35f, 0.20f, 0.10f));
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(0.3f, 0.15f, 0.08f));
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 32.0f);

	// Low Right Side Light
	m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(12.0f, 6.0f, -6.0f));
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.05f, 0.05f, 0.08f));
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", glm::vec3(0.20f, 0.20f, 0.30f));
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", glm::vec3(0.15f, 0.15f, 0.25f));
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 32.0f);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines material properties (ambient, diffuse, specular, shininess)
 *  for the objects in the scene so they interact correctly with light.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	//  Ceramic Material
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.tag = "ceramicMaterial";
	ceramicMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	ceramicMaterial.ambientStrength = 0.1f;
	ceramicMaterial.diffuseColor = glm::vec3(0.25f, 0.25f, 0.25f);
	ceramicMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	ceramicMaterial.shininess = 32.0f;
	m_objectMaterials.push_back(ceramicMaterial);

	//  Metal Material
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.tag = "metalMaterial";
	metalMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.ambientStrength = 0.1f;
	metalMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	metalMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(metalMaterial);

	//  Wood Material
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.tag = "woodMaterial";
	woodMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.ambientStrength = 0.1f;
	woodMaterial.diffuseColor = glm::vec3(0.25f, 0.25f, 0.25f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 16.0f;
	m_objectMaterials.push_back(woodMaterial);

	//  Fabric Material
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.tag = "fabricMaterial";
	fabricMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	fabricMaterial.ambientStrength = 0.1f;
	fabricMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	fabricMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	fabricMaterial.shininess = 8.0f;
	m_objectMaterials.push_back(fabricMaterial);

	//  Default
	OBJECT_MATERIAL defaultMaterial;
	defaultMaterial.tag = "default";
	defaultMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	defaultMaterial.ambientStrength = 0.1f;
	defaultMaterial.diffuseColor = glm::vec3(0.25f, 0.25f, 0.25f);
	defaultMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	defaultMaterial.shininess = 32.0f;
	m_objectMaterials.push_back(defaultMaterial);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads the textures used in the 3D scene.
 *********************************--------------------------*/
void SceneManager::LoadSceneTextures()
{
	CreateGLTexture("textures/vase.jpg", "ceramicTexture");
	CreateGLTexture("textures/othervase.jpg", "otherTexture");
	CreateGLTexture("textures/cushion.jpg", "cushionTexture");
	CreateGLTexture("textures/metal.jpg", "metalTexture");
	CreateGLTexture("textures/wood.jpg", "woodTexture");
	CreateGLTexture("textures/whitecloset.jpg", "closetTexture");

	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	// Load the textures first so they are ready in memory
	LoadSceneTextures();

	// Initialize object materials and scene lights so lighting works properly
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.749f, 0.722f, 0.702f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// Back Wall
	scaleXYZ = glm::vec3(20.0f, 1.0f, 12.0f);
	positionXYZ = glm::vec3(0.0f, 6.0f, -5.0f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawPlaneMesh();

	// Seat Cushion 
	scaleXYZ = glm::vec3(0.72f, 0.5f, 0.6f);
	positionXYZ = glm::vec3(-2.0f, 1.0f, -1.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("cushionTexture");
	SetShaderMaterial("fabricMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Stool Leg 1 (Front-Left)
	scaleXYZ = glm::vec3(0.05f, 1.2f, 0.05f);
	positionXYZ = glm::vec3(-2.6f, 0.0f, -0.6f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
	SetShaderTexture("metalTexture");
	SetShaderMaterial("metalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Stool Leg 2 (Front-Right)
	scaleXYZ = glm::vec3(0.05f, 1.2f, 0.05f);
	positionXYZ = glm::vec3(-1.4f, 0.0f, -0.6f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
	SetShaderTexture("metalTexture");
	SetShaderMaterial("metalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Stool Leg 3 (Back-Left)
	scaleXYZ = glm::vec3(0.05f, 1.2f, 0.05f);
	positionXYZ = glm::vec3(-2.6f, 0.0f, -1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
	SetShaderTexture("metalTexture");
	SetShaderMaterial("metalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Stool Leg 4 (Back-Right)
	scaleXYZ = glm::vec3(0.05f, 1.2f, 0.05f);
	positionXYZ = glm::vec3(-1.4f, 0.0f, -1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
	SetShaderTexture("metalTexture");
	SetShaderMaterial("metalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Left Closet
	scaleXYZ = glm::vec3(3.5f, 10.0f, 3.0f);
	positionXYZ = glm::vec3(-5.5f, 5.0f, -4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.85f, 0.85f, 0.88f, 1.0f);
	SetShaderTexture("closetTexture");
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawBoxMesh();

	// Left Closet: Vertical (Center split)
	scaleXYZ = glm::vec3(0.02f, 9.96f, 3.02f);
	positionXYZ = glm::vec3(-5.5f, 5.0f, -4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.75f, 0.77f, 0.80f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawBoxMesh();

	// Left Closet: Horizontal (Center split)
	scaleXYZ = glm::vec3(3.52f, 0.02f, 3.02f);
	positionXYZ = glm::vec3(-5.5f, 7.5f, -4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.75f, 0.77f, 0.80f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawBoxMesh();

	// Left Closet Handle 
	scaleXYZ = glm::vec3(0.08f, 2.0f, 0.08f);
	positionXYZ = glm::vec3(-5.5f, 5.0f, -2.45f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawBoxMesh();

	// Right Closet
	scaleXYZ = glm::vec3(3.5f, 10.0f, 3.0f);
	positionXYZ = glm::vec3(5.5f, 5.0f, -4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.85f, 0.85f, 0.88f, 1.0f);
	SetShaderTexture("closetTexture");
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawBoxMesh();

	// Right Closet: Vertical (Center split)
	scaleXYZ = glm::vec3(0.02f, 9.96f, 3.02f);
	positionXYZ = glm::vec3(5.5f, 5.0f, -4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.75f, 0.77f, 0.80f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawBoxMesh();

	// Right Closet: Horizontal (Center split)
	scaleXYZ = glm::vec3(3.52f, 0.02f, 3.02f);
	positionXYZ = glm::vec3(5.5f, 7.5f, -4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.75f, 0.77f, 0.80f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawBoxMesh();

	// Right Closet Handle
	scaleXYZ = glm::vec3(0.08f, 2.0f, 0.08f);
	positionXYZ = glm::vec3(5.5f, 5.0f, -2.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
	SetShaderMaterial("default");
	m_basicMeshes->DrawBoxMesh();

	// Desk Surface
	scaleXYZ = glm::vec3(7.4f, 0.5f, 2.5f);
	positionXYZ = glm::vec3(0.0f, 2.5f, -3.6f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.643f, 0.557f, 0.502f, 1.0f);
	SetShaderTexture("woodTexture");
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawBoxMesh();

	// Vase Bulbous Body (Cylinder Base)
	scaleXYZ = glm::vec3(0.24f, 0.32f, 0.24f);
	positionXYZ = glm::vec3(1.8f, 2.8f, -3.3f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramicTexture");
	SetShaderMaterial("ceramicMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Vase Shoulder (Sphere Middle Connection)
	scaleXYZ = glm::vec3(0.4f, 0.4f, 0.4f);
	positionXYZ = glm::vec3(1.8f, 3.3f, -3.3f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramicTexture");
	SetShaderMaterial("ceramicMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// Vase Head (Cylinder Top)
	scaleXYZ = glm::vec3(0.2f, 1.25f, 0.2f);
	positionXYZ = glm::vec3(1.8f, 3.2f, -3.3f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramicTexture");
	SetShaderMaterial("ceramicMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Vase Left Handle
	scaleXYZ = glm::vec3(0.06f, 0.25f, 0.08f);
	positionXYZ = glm::vec3(1.6f, 3.9f, -3.3f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramicTexture");
	SetShaderMaterial("ceramicMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Vase Right Handle
	scaleXYZ = glm::vec3(0.06f, 0.25f, 0.08f);
	positionXYZ = glm::vec3(2.0f, 3.9f, -3.3f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramicTexture");
	SetShaderMaterial("ceramicMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Desk Open Book
	scaleXYZ = glm::vec3(1.2f, 0.08f, 0.74f);
	positionXYZ = glm::vec3(-0.5f, 2.76f, -3.6f);
	SetTransformations(scaleXYZ, 0.0f, 345.0f, 0.0f, positionXYZ);
	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Middle Wooden Shelf
	scaleXYZ = glm::vec3(7.4f, 0.25f, 2.2f);
	positionXYZ = glm::vec3(0.0f, 5.0f, -3.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.643f, 0.557f, 0.502f, 1.0f);
	SetShaderTexture("woodTexture");
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawBoxMesh();

	// Middle Shelf Bottom Bowl Part
	scaleXYZ = glm::vec3(0.3f, 0.25f, 0.3f);
	positionXYZ = glm::vec3(-2.5f, 5.1f, -3.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("otherTexture");
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Middle Shelf Bowl Top Part
	scaleXYZ = glm::vec3(0.45f, 0.35f, 0.45f);
	positionXYZ = glm::vec3(-2.5f, 5.6f, -3.7f);
	SetTransformations(scaleXYZ, 180.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("otherTexture");
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Middle Shelf: Leaning Book
	scaleXYZ = glm::vec3(0.06f, 1.1f, 0.8f);
	positionXYZ = glm::vec3(-3.5f, 5.5f, -3.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 12.0f, positionXYZ);
	SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Middle Shelf Ribbed Container
	scaleXYZ = glm::vec3(0.25f, 0.8f, 0.25f);
	positionXYZ = glm::vec3(2.5f, 5.0f, -3.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// 2. Torus Ring 1 (Top)
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);
	positionXYZ = glm::vec3(2.5f, 5.80f, -3.7f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// 3. Torus Ring 2 (Upper-Middle)
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);
	positionXYZ = glm::vec3(2.5f, 5.62f, -3.7f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// 3. Torus Ring 3 (Middle)
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);
	positionXYZ = glm::vec3(2.5f, 5.45f, -3.7f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// 4. Torus Ring 4 (Lower-Middle)
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);
	positionXYZ = glm::vec3(2.5f, 5.28f, -3.7f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// 5. Torus Ring 5 (Bottom)
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);
	positionXYZ = glm::vec3(2.5f, 5.15f, -3.7f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// Middle Shelf Small Bowl
	scaleXYZ = glm::vec3(0.26f, 0.35f, 0.26f);
	positionXYZ = glm::vec3(1.75f, 5.35f, -3.7f);
	SetTransformations(scaleXYZ, 180.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.65f, 0.65f, 0.65f, 1.0f);
	SetShaderTexture("otherTexture");
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Top Wooden Shelf
	scaleXYZ = glm::vec3(7.4f, 0.25f, 2.2f);
	positionXYZ = glm::vec3(0.0f, 7.1f, -3.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.643f, 0.557f, 0.502f, 1.0f);
	SetShaderTexture("woodTexture");
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawBoxMesh();

	// Top Shelf: Spherical Vase
	scaleXYZ = glm::vec3(0.35f, 0.32f, 0.35f);
	positionXYZ = glm::vec3(1.2f, 7.4f, -3.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("otherTexture");
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawSphereMesh();

	// Twig 1
	scaleXYZ = glm::vec3(0.012f, 1.1f, 0.012f);
	positionXYZ = glm::vec3(1.15f, 7.52f, -3.7f);
	SetTransformations(scaleXYZ, -12.0f, 0.0f, -18.0f, positionXYZ);
	SetShaderColor(0.35f, 0.3f, 0.25f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Offshoot Branch 1
	scaleXYZ = glm::vec3(0.009f, 0.38f, 0.009f);
	positionXYZ = glm::vec3(1.08f, 7.95f, -3.58f);
	SetTransformations(scaleXYZ, -12.0f, 0.0f, -15.0f, positionXYZ);
	SetShaderColor(0.35f, 0.3f, 0.25f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Twig 2
	scaleXYZ = glm::vec3(0.012f, 1.2f, 0.012f);
	positionXYZ = glm::vec3(1.25f, 7.53f, -3.7f);
	SetTransformations(scaleXYZ, 15.0f, 0.0f, 22.0f, positionXYZ);
	SetShaderColor(0.35f, 0.3f, 0.25f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Offshoot Branch 2
	scaleXYZ = glm::vec3(0.009f, 0.38f, 0.009f);
	positionXYZ = glm::vec3(1.40f, 8.30f, -3.85f);
	SetTransformations(scaleXYZ, 15.0f, 0.0f, 30.0f, positionXYZ);
	SetShaderColor(0.35f, 0.3f, 0.25f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();
}